License And Terms Of Use

1) All files, Code, Models And Assets are soley bought And owned by myself War3zuk, You are free to download And play in Single Player, Your are also allowed
to Upload those Files to a server in order to play Online Assuming you own a Legal Copy of the game (7 Days To Die)

2) You are NOT Permitted to Alter any Code, Change or Rename any Models or Redistrabute without the Express permission of myself, War3zuk

3) All mods released by Myself, War3zuk, will always start with War3zuk in its Folder Name, such as War3zuk Alpha 18 AIO.
Users of War3zuk Alpha 18 AIO are also free to tailor their experience to their needs by altering the XML files. When hosting a server or game with such altered
contents But Due to the Models being Held under Unity's Single User License & Being Owned by Me, War3zuk you are NOT permitted to Share these modifications without
expression permission of myself, War3zuk. You MUST seek permission from myself before files, Code, Models or Assets that are contained within my Overhaul are
shared other than on your PC or on a Dedicated server for private use.

4) Users are NOT allowed to take the code from this mod to add to another mod in any way without first asking Me, War3zuk For explicit permission. This applies 
too taking (parts of) the code, XML or assets as well as altered versions of these. War3zuk is intended to be used as is and not to be broken down or redistributed
in an altered form unless you have explplicit permission. This includes adding any part of War3zuk into any kind of overhaul mod or mod collection pack.

All Rights Reserved, 2018,2019,2020..

Alpha 19 Modlet Repo

License And Terms Of Use

    All files, Code, Models And Assets are soley bought And owned by myself War3zuk, You are free to download And play in
    Single Player, Your are also allowed to Upload those Files to a server in order to play Online Assuming you own a Legal
    Copy of the game (7 Days To Die)

    You are NOT Permitted to Alter any Code, Change or Rename any Models or Redistrabute without the Express permission of
    myself, War3zuk

    All mods released by Myself, War3zuk, will always start with War3zuk in its Folder Name, such as War3zuk Alpha 18 AIO.
    Users of War3zuk Alpha 18 AIO are also free to tailor their experience to their needs by altering the XML files. When
    hosting a server or game with such altered contents But Due to the Models being Held under Unity's Single User License
    & Being Owned by Me, War3zuk you are NOT permitted to Share these modifications without expression permission of myself,
    War3zuk. You MUST seek permission from myself before files, Code, Models or Assets that are contained within my Overhaul
    are shared other than on your PC or on a Dedicated server for private use.

    Users are NOT allowed to take the code from this mod to add to another mod in any way without first asking Me, War3zuk
    For explicit permission. This applies too taking (parts of) the code, XML or assets as well as altered versions of these.
    War3zuk is intended to be used as is and not to be broken down or redistributed in an altered form unless you have
    explplicit permission. This includes adding any part of War3zuk into any kind of overhaul mod or mod collection pack.

All Rights Reserved, 2018,2019,2020,2021,2022..